import AnimatedWord from './AnimatedWord';

export default AnimatedWord;
