
interface IProps {
    open: boolean,
    className?: string
}

export type {
    IProps
}
