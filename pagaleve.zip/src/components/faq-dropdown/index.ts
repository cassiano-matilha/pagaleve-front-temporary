import FaqDropdown from './FaqDropdown';

export default FaqDropdown;
