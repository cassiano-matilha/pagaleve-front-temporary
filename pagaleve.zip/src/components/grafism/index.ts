import Grafism from './Grafism';

export default Grafism;
