interface IProps {
    items: Array<any>,
    className?: string,
}

export type {
    IProps
}
