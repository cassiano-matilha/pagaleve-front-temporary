import IconFloating from './IconFloating';

export default IconFloating;
