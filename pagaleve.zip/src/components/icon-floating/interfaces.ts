interface IProps {
    name: string,
    className?: string
}

export type {
    IProps
}