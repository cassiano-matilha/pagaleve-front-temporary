import IconCard from './IconCard';

export default IconCard;
