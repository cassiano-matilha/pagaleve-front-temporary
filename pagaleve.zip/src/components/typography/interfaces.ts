interface IProps {
	variant: string,
	color?: string,
	className?: string,
	mobile?: boolean
}

export type {
    IProps
};