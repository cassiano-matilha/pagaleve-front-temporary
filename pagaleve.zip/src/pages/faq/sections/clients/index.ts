import FrequentlyAskedQuestions from './FrequentlyAskedQuestions';

export default FrequentlyAskedQuestions;
