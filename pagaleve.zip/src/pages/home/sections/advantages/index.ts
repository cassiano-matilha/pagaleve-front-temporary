import Advantages from './Advantages';

export default Advantages;
