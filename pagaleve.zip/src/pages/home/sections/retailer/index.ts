import Retailer from './Retailer';

export default Retailer;
