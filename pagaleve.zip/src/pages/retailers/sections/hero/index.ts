import HeroRetailer from './HeroRetailer';

export default HeroRetailer;
