import Statistics from './Statistics';

export default Statistics;
