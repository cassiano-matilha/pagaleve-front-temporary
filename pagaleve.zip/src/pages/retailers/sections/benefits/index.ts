import Benefits from './Benefits';

export default Benefits;
