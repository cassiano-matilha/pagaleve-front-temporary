import RetailerForm from './RetailerForm';

export default RetailerForm;
