import FrequentlyAskedQuestionsRetailer from './FrequentlyAskedQuestionsRetailer';

export default FrequentlyAskedQuestionsRetailer;
